<!DOCTYPE html>
<html>
<head>
    <title>Laravel</title>




</head>
<body>
</body>
</html><?php /**PATH D:\www\QR-Generator\resources\views/qrPDF.blade.php ENDPATH**/ ?>